package org.set4j;

/**
 * @author Tomas Mikenda
 *
 */
public class Set4JException extends RuntimeException
{

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

	public Set4JException(String arg0)
    {
	    super(arg0);
    }

	public Set4JException(Throwable arg0)
    {
	    super(arg0);
    }

	public Set4JException(String arg0, Throwable arg1)
    {
	    super(arg0, arg1);
    }

	
}
